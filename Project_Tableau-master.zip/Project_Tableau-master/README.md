# Project_Tableau
Project Description:
- Use ETL/ELT and a database (mongo or sql ) before putting the dashboard on top of it. 
- A dashboard page with multiple charts that update from the same data / tableau.
- Create at least one graph, or use one tableau component that isn't covered already.
- Three dashboards for tableau.