Create table olympicinfo (
identification VARCHAR(200),
athlete VARCHAR(200),
sex VARCHAR(200),
age VARCHAR(200),
height VARCHAR(200),
weight VARCHAR(200),
team VARCHAR(200),
NOC VARCHAR(200),	
games VARCHAR(200),
year VARCHAR(200),
season VARCHAR(200),
city VARCHAR(200),	
sport VARCHAR(200),
event VARCHAR(200),
medal VARCHAR(200)	
);
